

document.addEventListener("DOMContentLoaded", function () {

    // Display current year
    const year = document.getElementById("year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    // Navigation menu
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", function () {
            navLinks.classList.toggle("open");

            navToggle.setAttribute(
                "aria-expanded",
                navLinks.classList.contains("open")
            );
        });
    }

    // Contact form
    const form = document.getElementById("contact-form");

    if (!form) return;

    const fields = {
        name: {
            input: document.getElementById("name"),
            error: document.getElementById("name-error")
        },
        email: {
            input: document.getElementById("email"),
            error: document.getElementById("email-error")
        },
        phone: {
            input: document.getElementById("phone"),
            error: document.getElementById("phone-error")
        },
        subject: {
            input: document.getElementById("subject"),
            error: document.getElementById("subject-error")
        },
        message: {
            input: document.getElementById("message"),
            error: document.getElementById("message-error")
        }
    };

    const status = document.getElementById("form-status");

    // Clear previous errors
    function clearErrors() {
        Object.values(fields).forEach(function (field) {
            if (field.error) {
                field.error.textContent = "";
            }
        });
    }

    // Validate contact form
    function validate() {
        clearErrors();

        let valid = true;

        if (fields.name.input.value.trim().length < 2) {
            fields.name.error.textContent =
                "Name must be at least 2 characters long.";
            valid = false;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(fields.email.input.value.trim())) {
            fields.email.error.textContent =
                "Please enter a valid email address.";
            valid = false;
        }

        const phonePattern = /^\+?\d{10,15}$/;

        if (!phonePattern.test(fields.phone.input.value.trim())) {
            fields.phone.error.textContent =
                "Please enter a valid phone number.";
            valid = false;
        }

        if (fields.subject.input.value.trim().length < 2) {
            fields.subject.error.textContent =
                "Subject must be at least 2 characters long.";
            valid = false;
        }

        if (fields.message.input.value.trim().length < 10) {
            fields.message.error.textContent =
                "Message must be at least 10 characters long.";
            valid = false;
        }

        return valid;
    }

    // Form submission
    form.addEventListener("submit", function (event) {
        event.preventDefault();

        if (validate()) {
            if (status) {
                status.textContent = "Form submitted successfully!";
                status.style.color = "green";
            }

            form.reset();
        } else {
            if (status) {
                status.textContent =
                    "Please correct the errors in the form.";
                status.style.color = "red";
            }
        }
    });

});

document.addEventListener("DOMContentLoaded", function () {

    // Navigation menu
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", function () {
            navLinks.classList.toggle("open");

            navToggle.setAttribute(
                "aria-expanded",
                navLinks.classList.contains("open")
            );
        });
    }

    // Shopping cart
    let cart = JSON.parse(
        localStorage.getItem("lumineCart")
    ) || [];

    function saveCart() {
        localStorage.setItem(
            "lumineCart",
            JSON.stringify(cart)
        );
    }

    function formatPrice(price) {
        return "R" + price.toFixed(2);
    }

    // Add products to cart
    document.querySelectorAll(".cart-button").forEach(button => {

        button.addEventListener("click", function () {

            const name = this.dataset.name;
            const price = Number(this.dataset.price);

            if (!name || !Number.isFinite(price) || price <= 0) {
                alert("Product information is incorrect.");
                return;
            }

            const existingProduct = cart.find(item =>
                item.name === name
            );

            if (existingProduct) {
                existingProduct.quantity++;
            } else {
                cart.push({
                    name: name,
                    price: price,
                    quantity: 1
                });
            }

            saveCart();
            displayCart();

            alert(name + " added to your shopping cart!");

        });

    });

    // Display shopping cart
    function displayCart() {

        const cartItems = document.getElementById("cartItems");
        const cartCount = document.getElementById("cartCount");
        const cartTotal = document.getElementById("cartTotal");

        if (!cartItems) return;

        cartItems.innerHTML = "";

        let total = 0;
        let count = 0;

        if (cart.length === 0) {
            cartItems.innerHTML =
                "<p>Your shopping cart is empty.</p>";
        }

        cart.forEach((item, index) => {

            const itemTotal = item.price * item.quantity;

            total += itemTotal;
            count += item.quantity;

            const cartRow = document.createElement("div");
            cartRow.className = "cart-product";

            const details = document.createElement("div");

            const productName = document.createElement("strong");
            productName.textContent = item.name;

            const productPrice = document.createElement("p");
            productPrice.textContent =
                formatPrice(item.price) + " each";

            details.append(productName, productPrice);

            const controls = document.createElement("div");
            controls.className = "quantity-controls";

            // Decrease quantity
            const decrease = document.createElement("button");
            decrease.type = "button";
            decrease.textContent = "-";

            decrease.addEventListener("click", function () {

                item.quantity--;

                if (item.quantity <= 0) {
                    cart.splice(index, 1);
                }

                saveCart();
                displayCart();

            });

            const quantity = document.createElement("span");
            quantity.textContent = item.quantity;

            // Increase quantity
            const increase = document.createElement("button");
            increase.type = "button";
            increase.textContent = "+";

            increase.addEventListener("click", function () {

                item.quantity++;

                saveCart();
                displayCart();

            });

            controls.append(decrease, quantity, increase);

            // Subtotal
            const subtotal = document.createElement("strong");
            subtotal.textContent = formatPrice(itemTotal);

            // Remove product
            const remove = document.createElement("button");
            remove.type = "button";
            remove.textContent = "Remove";
            remove.className = "remove-button";

            remove.addEventListener("click", function () {

                cart.splice(index, 1);

                saveCart();
                displayCart();

            });

            cartRow.append(details, controls, subtotal, remove);
            cartItems.appendChild(cartRow);

        });

        if (cartCount) {
            cartCount.textContent = count;
        }

        if (cartTotal) {
            cartTotal.textContent = formatPrice(total);
        }

    }

    // Clear shopping cart
    const clearCart = document.getElementById("clearCart");

    if (clearCart) {

        clearCart.addEventListener("click", function () {

            if (cart.length === 0) {
                alert("Your cart is already empty.");
                return;
            }

            if (confirm("Are you sure you want to clear your cart?")) {
                cart = [];

                saveCart();
                displayCart();
            }

        });

    }

    // Load saved cart
    displayCart();


    // PRODUCT GALLERY LIGHTBOX

    const productImages = document.querySelectorAll(
        ".product-container .product-card img"
    );

    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightbox-img");
    const caption = document.getElementById("lightbox-caption");
    const closeButton = document.querySelector(".lightbox-close");

    if (lightbox && lightboxImage && caption && closeButton) {

        // Open enlarged image
        productImages.forEach(image => {

            image.style.cursor = "pointer";

            image.addEventListener("click", function () {

                lightboxImage.src = this.src;
                lightboxImage.alt = this.alt;
                caption.textContent = this.alt;

                lightbox.style.display = "flex";
                document.body.style.overflow = "hidden";

            });

        });

        // Close lightbox
        function closeLightbox() {
            lightbox.style.display = "none";
            document.body.style.overflow = "";
        }

        closeButton.addEventListener("click", closeLightbox);

        // Close when clicking outside image
        lightbox.addEventListener("click", function (event) {

            if (event.target === lightbox) {
                closeLightbox();
            }

        });

        // Close with Escape key
        document.addEventListener("keydown", function (event) {

            if (event.key === "Escape") {
                closeLightbox();
            }

        });

    }

});


document.addEventListener("DOMContentLoaded", function () {

    // IMPORTANT:
    // Replace this number with your Lumine business WhatsApp number.
    // Use country code without +, spaces or leading zero.
    // Example South African number: 0660957590

    const BUSINESS_WHATSAPP = "0660957590";

    // Product prices
    const prices = {
        "Lumine Bella": 160,
        "Lumine Noir": 160,
        "Lumine Gold": 160,
        "Lumine Ocean": 160,
        "Lumine Rose": 160,
        "Lumine Violet": 160,
        "Lumine Fresh": 160,
        "Lumine Intense": 160,
        "Lumine Gift Set": 320
    };

    // Delivery prices
    const deliveryPrices = {
        "Standard Delivery": 80,
        "Express Delivery": 120,
        "Collection": 0
    };

    // Load shopping cart
    let cart = JSON.parse(
        localStorage.getItem("lumineCart")
    ) || [];

    // Validate saved cart
    cart = cart.filter(item =>
        item &&
        Object.prototype.hasOwnProperty.call(prices, item.name) &&
        Number.isInteger(Number(item.quantity)) &&
        Number(item.quantity) > 0
    );

    cart = cart.map(item => ({
        name: item.name,
        price: prices[item.name],
        quantity: Number(item.quantity)
    }));

    const cartItems = document.getElementById("cartItems");
    const delivery = document.getElementById("delivery");
    const orderForm = document.getElementById("orderForm");
    const placeOrderButton =
        document.getElementById("placeOrderButton");

    const orderStatus = document.getElementById("orderStatus");

    // Display current year
    const year = document.getElementById("year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    // Save cart
    function saveCart() {
        localStorage.setItem(
            "lumineCart",
            JSON.stringify(cart)
        );
    }

    // Format currency
    function money(amount) {
        return "R" + amount.toFixed(2);
    }

    // Calculate subtotal
    function getSubtotal() {
        return cart.reduce((sum, item) => {
            return sum + item.price * item.quantity;
        }, 0);
    }

    // Display cart
    function displayCart() {

        cartItems.innerHTML = "";

        if (cart.length === 0) {

            cartItems.textContent =
                "Your shopping cart is empty.";

            placeOrderButton.disabled = true;

        } else {

            placeOrderButton.disabled = false;

            cart.forEach((item, index) => {

                const row = document.createElement("div");
                row.className = "cart-product";

                const details = document.createElement("div");

                const name = document.createElement("strong");
                name.textContent = item.name;

                const price = document.createElement("p");
                price.textContent = money(item.price) + " each";

                details.append(name, price);

                // Quantity controls
                const controls = document.createElement("div");
                controls.className = "quantity-controls";

                const decrease = document.createElement("button");
                decrease.type = "button";
                decrease.textContent = "-";

                decrease.addEventListener("click", function () {

                    item.quantity--;

                    if (item.quantity <= 0) {
                        cart.splice(index, 1);
                    }

                    saveCart();
                    displayCart();

                });

                const quantity = document.createElement("span");
                quantity.textContent = item.quantity;

                const increase = document.createElement("button");
                increase.type = "button";
                increase.textContent = "+";

                increase.addEventListener("click", function () {

                    item.quantity++;

                    saveCart();
                    displayCart();

                });

                controls.append(decrease, quantity, increase);

                const subtotal = document.createElement("strong");

                subtotal.textContent = money(
                    item.price * item.quantity
                );

                const remove = document.createElement("button");
                remove.type = "button";
                remove.textContent = "Remove";
                remove.className = "remove-button";

                remove.addEventListener("click", function () {

                    cart.splice(index, 1);

                    saveCart();
                    displayCart();

                });

                row.append(details, controls, subtotal, remove);

                cartItems.appendChild(row);

            });

        }

        updateTotal();

    }

    // Calculate order total
    function updateTotal() {

        const subtotal = getSubtotal();

        const deliveryCost =
            deliveryPrices[delivery.value] || 0;

        document.getElementById("itemsSubtotal").textContent =
            money(subtotal);

        document.getElementById("summaryDelivery").textContent =
            money(deliveryCost);

        document.getElementById("total").textContent =
            money(subtotal + deliveryCost);

    }

    // Update total when delivery changes
    delivery.addEventListener("change", updateTotal);

    // Submit order to WhatsApp
    orderForm.addEventListener("submit", function (event) {

        event.preventDefault();

        if (cart.length === 0) {
            alert("Please add products to your shopping cart.");
            return;
        }

        if (!orderForm.reportValidity()) {
            return;
        }

        // Customer details
        const customerName =
            document.getElementById("name").value.trim();

        const customerPhone =
            document.getElementById("phone").value.trim();

        const customerEmail =
            document.getElementById("email").value.trim();

        const customerAddress =
            document.getElementById("address").value.trim();

        const paymentMethod =
            document.getElementById("payment").value;

        const deliveryMethod = delivery.value;

        // Calculate totals
        const subtotal = getSubtotal();

        const deliveryCost =
            deliveryPrices[deliveryMethod] || 0;

        const total = subtotal + deliveryCost;

        // Create order reference
        const orderNumber =
            "LUM-" + Date.now().toString().slice(-8);

        // Prepare product list
        let productDetails = "";

        cart.forEach(item => {

            productDetails +=
                "\n" + item.name +
                "\nQuantity: " + item.quantity +
                "\nPrice: " + money(item.price) +
                "\nSubtotal: " +
                money(item.price * item.quantity) +
                "\n";

        });

        // Create WhatsApp message
        const message =
            "HELLO LUMINE PERFUME!\n\n" +

            "I would like to place an order.\n\n" +

            "ORDER NUMBER: " + orderNumber +
            "\n\n" +

            "CUSTOMER DETAILS\n" +
            "Name: " + customerName + "\n" +
            "Phone: " + customerPhone + "\n" +
            "Email: " + customerEmail + "\n" +
            "Address: " + customerAddress + "\n\n" +

            "ORDER DETAILS\n" +
            productDetails +

            "\nSubtotal: " + money(subtotal) +
            "\nDelivery: " + deliveryMethod +
            "\nDelivery Cost: " + money(deliveryCost) +
            "\nPayment Method: " + paymentMethod +

            "\n\nTOTAL: " + money(total) +

            "\n\nPlease confirm my order. Thank you!";

        // Validate business WhatsApp number
        if (!/^\d{10,15}$/.test(BUSINESS_WHATSAPP)) {
            alert("Please enter a valid business WhatsApp number.");
            return;
        }

        // Save order locally as pending
        const savedOrders = JSON.parse(
            localStorage.getItem("lumineOrders")
        ) || [];

        const newOrder = {
            orderNumber: orderNumber,
            customerName: customerName,
            customerPhone: customerPhone,
            customerEmail: customerEmail,
            address: customerAddress,
            products: cart,
            delivery: deliveryMethod,
            payment: paymentMethod,
            subtotal: subtotal,
            deliveryCost: deliveryCost,
            total: total,
            status: "Pending WhatsApp confirmation",
            date: new Date().toLocaleString()
        };

        savedOrders.push(newOrder);

        localStorage.setItem(
            "lumineOrders",
            JSON.stringify(savedOrders)
        );

        // Open WhatsApp
        const whatsappURL =
            "https://wa.me/" +
            BUSINESS_WHATSAPP +
            "?text=" +
            encodeURIComponent(message);

        window.open(whatsappURL, "_blank");

        if (orderStatus) {
            orderStatus.textContent =
                "Your order has been prepared. Please send the WhatsApp message to complete your order.";
        }

    });

    // Initial display
    saveCart();
    displayCart();

});


document.addEventListener("DOMContentLoaded", function () {

    // Replace with your business WhatsApp number
    const BUSINESS_WHATSAPP = "27821234567";

    // Current year
    document.getElementById("year").textContent =
        new Date().getFullYear();

    const form = document.getElementById("enquiryForm");
    const status = document.getElementById("enquiryStatus");

    form.addEventListener("submit", function (event) {

        event.preventDefault();

        // Customer information
        const name = document.getElementById("enquiryName")
            .value.trim();

        const email = document.getElementById("enquiryEmail")
            .value.trim();

        const phone = document.getElementById("enquiryPhone")
            .value.trim();

        const type = document.getElementById("enquiryType")
            .value;

        const product = document.getElementById("productName")
            .value.trim();

        const message = document.getElementById("enquiryMessage")
            .value.trim();

        // Validate information
        const phonePattern = /^\+?\d{10,15}$/;

        if (name.length < 2) {
            status.textContent = "Please enter your full name.";
            return;
        }

        if (!phonePattern.test(phone)) {
            status.textContent =
                "Please enter a valid phone number.";
            return;
        }

        if (message.length < 10) {
            status.textContent =
                "Please enter an enquiry of at least 10 characters.";
            return;
        }

        if (!/^\d{10,15}$/.test(BUSINESS_WHATSAPP)) {
            status.textContent =
                "Please configure the business WhatsApp number.";
            return;
        }

        // Create WhatsApp enquiry
        const whatsappMessage =
            "LUMINE PERFUME - CUSTOMER ENQUIRY\n\n" +

            "Customer Details\n" +
            "Name: " + name + "\n" +
            "Email: " + email + "\n" +
            "Phone: " + phone + "\n\n" +

            "Enquiry Details\n" +
            "Enquiry Type: " + type + "\n" +
            "Product: " + (product || "Not specified") + "\n" +
            "Message: " + message + "\n\n" +

            "Thank you for assisting me.";

        const whatsappURL =
            "https://wa.me/" +
            BUSINESS_WHATSAPP +
            "?text=" +
            encodeURIComponent(whatsappMessage);

        // Open WhatsApp
        const whatsappWindow = window.open(
            whatsappURL,
            "_blank"
        );

        if (!whatsappWindow) {
            status.textContent =
                "WhatsApp could not open. Please allow pop-ups and try again.";
            return;
        }

        status.textContent =
            "Your enquiry is ready. Please send the WhatsApp message.";

    });

});

